# База данных
Host_DB = 'vkusnitz.beget.tech'
User_DB = 'vkusnitz_rm'
Password_DB = '/XD?fHHAbS5=dvG!s%{('
Name_DB = 'vkusnitz_rm'

# Реклама
ads_Token = ''

# Telegram-бот
tg_Token = ''