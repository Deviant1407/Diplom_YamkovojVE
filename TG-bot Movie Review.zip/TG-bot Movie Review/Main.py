import Conf

import mysql.connector
import telebot
import requests
import datetime
import time
import hashlib

# БД
def Connect_DB ():
    db = mysql.connector.connect(host=Conf.Host_DB, user=Conf.User_DB, password=Conf.Password_DB, database=Conf.Name_DB)

    if db.is_connected():
        return db
    else:
        return None

def Use_DB (db : mysql.connector.connection.MySQLConnection, Qwery : str):
    Cursor = db.cursor()
    Cursor.execute(Qwery)

    if Qwery[0:6].upper() == "SELECT": #SELECT
        Result = Cursor.fetchall()
        Cursor.close()
    
    elif Qwery[0:6].upper() == "INSERT": #INSERT
        db.commit()

        Result = Cursor.lastrowid
        Cursor.close()

    elif Qwery[0:6].upper() in ("UPDATE","DELETE"): #UPDATE и DELETE
        db.commit()

        Result = Cursor.rowcount
        Cursor.close()
    
    else:
        Result = None
        Cursor.close()
    
    return Result

def Close_DB (db : mysql.connector.connection.MySQLConnection):
    db.close()

# Шифрование
def SHA224(data : str):
    return hashlib.sha224(data.encode()).hexdigest()

# Проверки и работа с БД
def Check_T_ID (Telegram_ID: int):
    DB = Connect_DB()

    try:
        User_Data = Use_DB(DB, f'Select `Username` from `User` where `Telegram_ID` = {Telegram_ID};')
        User_Data = [User[0] for User in User_Data]

        if not User_Data:
            return False
        
        else:
            return True

    finally:
        Close_DB(DB)

def Check_Login (Login : str):
    DB = Connect_DB()

    try:
        User_Login = Use_DB(DB, f'Select `Username` from `User` where `Username` = "{Login}";')
        
        if not User_Login:
            return False
        else:
            return True

    finally:
        Close_DB(DB)

def Check_Password (Password : str):
    DB = Connect_DB()

    try:
        User_Password = Use_DB(DB, f'Select `Password` from `User` where `Password` = "{SHA224(Password)}";')
        
        if not User_Password:
            return False
        else:
            return True

    finally:
        Close_DB(DB)

def Update_User (Telegram_ID: int, Username : str):
    DB = Connect_DB()

    try:
        User_Password = Use_DB(DB, f'UPDATE `User` SET `Telegram_ID` = "{Telegram_ID}" WHERE `User`.`Username` = "{Username}";')

    finally:
        Close_DB(DB)

def Get_Role_User (Telegram_ID: int):
    DB = Connect_DB()

    try:
        User_Role = Use_DB(DB, f'Select `ID_role` from `User` where `Telegram_ID` = {Telegram_ID};')
        User_Role = User_Role[0][0]

        Name_Role = Use_DB(DB, f'Select `Name` from `Role` where `ID` = {User_Role};')
        Name_Role = Name_Role[0][0]

        return Name_Role

    finally:
        Close_DB(DB)

def Get_Name_User (Telegram_ID: int):
    DB = Connect_DB()

    try:
        User_Name = Use_DB(DB, f'Select `Username` from `User` where `Telegram_ID` = {Telegram_ID};')
        User_Name = User_Name[0][0]

        return User_Name

    finally:
        Close_DB(DB)

def Get_Info_Users ():
    DB = Connect_DB()

    try:
        User_Data = Use_DB(DB, f'Select `ID_Gender`, `Age` from `User`;')

        return User_Data

    finally:
        Close_DB(DB)

def Get_Info_User(Telegram_ID: int):
    DB = Connect_DB()

    try:
        User_Data = Use_DB(DB, f'Select `Username`, `FIO`, `ID_Gender`, `Age`, `Email` from `User` where `Telegram_ID` = {Telegram_ID};')
        User_Data = User_Data[0]

        return User_Data

    finally:
        Close_DB(DB)

def Get_User_Actives (Telegram_ID: int):
    DB = Connect_DB()

    try:
        ID_User = Use_DB(DB, f"Select `ID` from `User` where `Telegram_ID` = {Telegram_ID};")
        ID_User = ID_User[0][0]

        Actives = Use_DB(DB, f"Select `ID_film`, `Evaluation`, `Like_` from `Active` where `ID_user` = {ID_User};")

        return Actives

    finally:
        Close_DB(DB)

def Get_Info_Film (ID : int):
    DB = Connect_DB()

    try:
       Data_Film = Use_DB(DB, f'Select `Name`, `Description`, `Season`, `Series`, `Evaluation_Average`, `Release_Year`, `Country`, `Genre`, `URL_Image`, `Web_Url` from `Films` where `ID` = {ID};')
       Data_Film = Data_Film[0]

       return Data_Film

    finally:
        Close_DB(DB)

def Insert_FeedBack (Telegram_ID: int, Evaluation: int, Comment : str):
    DB = Connect_DB()

    try:
        User_ID = Use_DB(DB, f'SELECT `ID` from `User` where `Telegram_ID` = {Telegram_ID};')
        User_ID = User_ID[0][0]

        Use_DB(DB, f'INSERT INTO `Feedback` (`ID_user`, `Message`, `Evaluation`) VALUES ({User_ID}, "{Comment}", {Evaluation});')

    finally:
        Close_DB(DB)

def Insert_Active(Telegram_ID : int, ID_film : int, Evaluation : int = -1, Like_ : int = 0):
    DB = Connect_DB()

    try:
        User_ID = Use_DB(DB, f'SELECT `ID` from `User` where `Telegram_ID` = {Telegram_ID};')
        User_ID = User_ID[0][0]

        if Evaluation != -1:
            Use_DB(DB, f'INSERT INTO `Active` (`ID_user`, `ID_film`, `Evaluation`, `Like_`) VALUES ({User_ID}, {ID_film}, {Evaluation}, {Like_});')
        else:
            Use_DB(DB, f'INSERT INTO `Active` (`ID_user`, `ID_film`, `Like_`) VALUES ({User_ID}, {ID_film}, {Like_});')

    finally:
        Close_DB(DB)

# Реклама
# Автономная реклама от Яндекса

# Реклама собственных проектов
def Project_Advertisement (message : telebot.types.Message):
    Bot.send_photo(message.chat.id, 'Logo-KonacaDev-fon.png',
    'Больше о проекте по [ссылке](https://konacadev.ru/catalog)', parse_mode='Markdown')

# Обработка оценок
def Update_Evaluation(time: datetime.datetime):
    if time.strftime("%H:%M") == "00:00":
        DB = Connect_DB()

        Films = Use_DB(DB, "Select `ID` from `Films`;")
        Active_Num = 0

        for i in range(len(Films)):
            Film = Films[i]

            ID = Film[0]

            Actives = Use_DB(DB, f"Select `Evaluation` from `Active` where `ID_film` = {ID};")
            Evaluation = [Evalu[0] for Evalu in Actives]

            Evaluation_Average = round(sum(Evaluation) / len(Evaluation), 2)

            Use_DB(DB, f"Update `Films` set `Evaluation_Average` = {Evaluation_Average} where `ID` = {ID};")

            Active_Num += len(Evaluation)

        # Логирование
        with open("Bot-log.txt", "w") as log_file:
            log_file.write(f'\nОбработка оценок \nДата: {time.strftime("%Y-%m-%d %H:%M")} \nКоличество активностей: {Active_Num} \nКоличество фильмов: {len(Films)}\n')

        Close_DB(DB)

        return True

    else:
        return False

# Удаление сообщения
def Delete_Message(chat_id : int, message_id : int):
    try:
        Bot.delete_message(chat_id, message_id)

    except Exception as e:
        print(f"Ошибка при удалении сообщения: {e}")

# Авторизация и регистрация
def Log (Login : str, Password : str, Telegram_ID : int):
    DB = Connect_DB()

    try:
        Check_User_Login = Use_DB(DB, f'Select `ID` from `User` where `Username`="{Login}";')
        Check_User_Login = Check_User_Login[0][0]

        if not Check_User_Login:
            return "Такого пользователя нет!"
        
        Check_User_Password = Use_DB(DB, f'Select `Password` from `User` where `Username`="{Login}";')
        Check_User_Password = Check_User_Password[0][0]

        if SHA224(Password) == Check_User_Password:
            Use_DB(DB, f'UPDATE `User` set `Telegram_ID`= {Telegram_ID} WHERE `ID`={Check_User_Login};')
            return True
        else:
            return False

    finally:
        Close_DB(DB)

def Reg (Username : str, FIO : str, Gender : int, Age : int, Password : str, Telegram_ID : int, ID_role : int, Email : str):
    DB = Connect_DB()

    try:
        Username_In_Sistem = Use_DB(DB, f'Select `Username` from `User` where `Username` = "{Username}";')
        if len(Username_In_Sistem) > 0:
            return False
        
        Email_In_Sistem = Use_DB(DB, f'Select `Email` from `User` where `Email` = "{Email}";')
        if len(Email_In_Sistem) > 0:
            return False

        Use_DB(DB, f'INSERT INTO `User` (`Username`, `FIO`, `ID_Gender`, `Age`, `Password`, `Telegram_ID`, `ID_role`, `Email`) VALUES ("{Username}", "{FIO}", {Gender}, {Age}, "{SHA224(Password)}", {Telegram_ID}, {ID_role}, "{Email}");')
        return True

    finally:
        Close_DB(DB)

# Рекомендательная система
def Rec_Algo(Telegram_ID: int):
    DB = Connect_DB()
    
    try:
        # Информация о пользователе
        User = Use_DB(DB, f"SELECT `ID` FROM `User` WHERE `Telegram_ID` = {Telegram_ID};")
        if not User:
            return None  # Пользователь не найден
        User = User[0][0]

        # Информация об активностях
        Actives = Use_DB(DB, f"SELECT `ID_film` FROM `Active` WHERE `ID_user` = {User};")
        Films = [Active[0] for Active in Actives]

        if not Films:  # Рекомендация новинок
            Rec = Use_DB(DB, "SELECT `URL_Image`, `Name`, `Web_Url` FROM `Films` ORDER BY `Date_at` DESC LIMIT 5;")
            return Rec

        # Определнние жанров
        Genre_Dict = {}

        Film_Str = ', '.join(f'"{Film}"' for Film in Films)

        Genre_List = Use_DB(DB, f'Select `Genre` from `Films` where `Name` in ({Film_Str});')
        Genre_List = [Genre[0] for Genre in Genre_List]

        for Genres in Genre_List:
        # Разделяем строку на отдельные жанры
            for Genre in Genres.split(', '):
                # Увеличиваем счетчик для каждого жанра
                if Genre in Genre_Dict:
                    Genre_Dict[Genre] += 1
                else:
                    Genre_Dict[Genre] = 1

        # Подсчёт влияния
        Total_Count = sum(Genre_Dict.values())

        Influence_Dict = {}
        
        for Genre, Count in Genre_Dict.items():
            Percent = round(((Count / Total_Count) * 100), 2)

            if 0 <= Percent <= 10:
                Influence_Dict[Genre] = 1
            elif 11 <= Percent <= 20:
                Influence_Dict[Genre] = 2
            elif 21 <= Percent <= 30:
                Influence_Dict[Genre] = 3
            elif 31 <= Percent <= 40:
                Influence_Dict[Genre] = 4
            elif 41 <= Percent <= 50:
                Influence_Dict[Genre] = 5
            elif 51 <= Percent <= 60:
                Influence_Dict[Genre] = 6
            elif 61 <= Percent <= 70:
                Influence_Dict[Genre] = 7
            elif 71 <= Percent <= 80:
                Influence_Dict[Genre] = 8
            elif 81 <= Percent <= 90:
                Influence_Dict[Genre] = 9
            elif 91 <= Percent <= 100:
                Influence_Dict[Genre] = 10

        # Рекомендация
        Sorted_Genres = sorted(Influence_Dict.items(), key=lambda item: item[1], reverse=True)
        Influence_List = [genre for genre, influence in Sorted_Genres]

        Genre_Str = ', '.join(f'"{Genre}"' for Genre in Influence_List)
        Rec = Use_DB(DB, f'Select `URL_Image`, `Name`, `Web_Url` from `Films` where `Genre` like in ({Genre_Str}) and `Name` not in ({Film_Str}) LIMIT 5;')

        return Rec

    finally:
        Close_DB(DB)

def Search(message : telebot.types.Message):
    DB = Connect_DB()
    Name = message.text

    try:
        Films = Use_DB(DB, f'Select `Name`, `Season`, `Series`, `Evaluation_Average`, `URL_Image`, `Web_Url`, `ID`, `Age_Rating` from `Films` where `Name` like "{Name}%"')
            
        if len(Films) > 0:
            # Project_Advertisement(message)
            for i in range(len(Films)):
                User_Save_Evaluation_Film()
                User_Save_Like_Film()

                keyboard = telebot.types.InlineKeyboardMarkup()
                Button_Like = telebot.types.InlineKeyboardButton("Лайк", callback_data=f'Like__')
                Button_Evaluation = telebot.types.InlineKeyboardButton("Оценка", callback_data=f'Evaluation__')
                Button_Send = telebot.types.InlineKeyboardButton("Отправить", callback_data=f'Send__{Films[i][6]}')
                keyboard.add(Button_Like, Button_Evaluation)
                keyboard.add(Button_Send)
                Bot.send_photo(message.chat.id, Films[i][4],
                           f'{Films[i][0]} \nВозрастной рейтинг: {Films[i][7]} \nОценка: {round(Films[i][3], 1)} \nСезонов: {Films[i][1]} \nСерий: {Films[i][2]} \n[Ссылка]({Films[i][5]})', 
                           parse_mode='Markdown', reply_markup=keyboard)
        
        else:
            Bot.send_message(message.chat.id,
                             f'Ничего не найдено. Если хотите повторить запрос, то /search')

    finally:
        Close_DB(DB)

# Функции
User_Data = {}

def Check_User_Save(Telegram_ID : int):
    Data = User_Data[Telegram_ID]

    if Data != None:
        return True
    else:
        return False

def New_User_Save(Telegram_ID : int):
    User_Data[Telegram_ID] = {}

def User_Save_Evaluation(Telegram_ID : int, Value : int = 10):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Evaluation"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Comment(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Comment"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def Update_G_Comment_T(message : telebot.types.Message):
    User_Save_Comment(message.chat.id, message.text)
    Bot.send_message(message.chat.id,
                         f'Данные сохранены!')

def User_Save_Evaluation_Film(Telegram_ID : int, Value : int = 10):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Evaluation_Film"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Like_Film(Telegram_ID : int, Value : int = 0):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Like_Film"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def Update_User_Name(Telegram_ID : int, Value : str):
    DB = Connect_DB()

    try:
        Use_DB(DB, f'UPDATE `User` SET `Username` = "{Value}" WHERE `User`.`Telegram_ID` = "{Telegram_ID}";')

    finally:
        Close_DB(DB)

def Update_User_FIO(Telegram_ID : int, Value : str):
    DB = Connect_DB()

    try:
        Use_DB(DB, f'UPDATE `User` SET `FIO` = "{Value}" WHERE `User`.`Telegram_ID` = "{Telegram_ID}";')

    finally:
        Close_DB(DB)

def Update_User_Gender(Telegram_ID : int, Value : int):
    DB = Connect_DB()

    try:
        Use_DB(DB, f'UPDATE `User` SET `Gender` = {Value} WHERE `User`.`Telegram_ID` = "{Telegram_ID}";')

    finally:
        Close_DB(DB)

def Update_User_Age(Telegram_ID : int, Value : int):
    DB = Connect_DB()

    try:
        Use_DB(DB, f'UPDATE `User` SET `Age` = {Value} WHERE `User`.`Telegram_ID` = "{Telegram_ID}";')

    finally:
        Close_DB(DB)

def Update_User_Email(Telegram_ID : int, Value : str):
    DB = Connect_DB()

    try:
        Use_DB(DB, f'UPDATE `User` SET `Email` = "{Value}" WHERE `User`.`Telegram_ID` = "{Telegram_ID}";')

    finally:
        Close_DB(DB)

def Update_User_Name_T(message : telebot.types.Message):
    Update_User_Name(message.chat.id, message.text)
    Bot.send_message(message.chat.id,
                     f'Данные обновлены!')

def Update_User_FIO_T(message : telebot.types.Message):
    Update_User_FIO(message.chat.id, message.text)
    Bot.send_message(message.chat.id,
                     f'Данные обновлены!')
    
def Update_User_Gender_T(message : telebot.types.Message):
    Update_User_Gender(message.chat.id, int(message.text))
    Bot.send_message(message.chat.id,
                     f'Данные обновлены!')
    
def Update_User_Age_T(message : telebot.types.Message):
    Update_User_Age(message.chat.id, int(message.text))
    Bot.send_message(message.chat.id,
                     f'Данные обновлены!')
    
def Update_User_Email_T(message : telebot.types.Message):
    Update_User_Email(message.chat.id, message.text)
    Bot.send_message(message.chat.id,
                     f'Данные обновлены!')

def User_Save_Username(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Username"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        return False

def Update_G_Username_T(message : telebot.types.Message):
    User_Save_Username(message.chat.id, message.text)
    Registration_FIO(message)

def User_Save_FIO(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["FIO"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Gender(Telegram_ID : int, Value : int = 1):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Gender"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Age(Telegram_ID : int, Value : int = 1):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Age"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Password(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Password"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Email(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Email"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Message(Telegram_ID : int, Value : int):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Message"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Auth_Login(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Auth_Login"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

def User_Save_Auth_Password(Telegram_ID : int, Value : str = ""):
    if Check_User_Save(Telegram_ID):
        Data = User_Data[Telegram_ID]
        Data["Auth_Password"] = Value
        User_Data[Telegram_ID] = Data

        return True
    else:
        New_User_Save(Telegram_ID)
        return False

# Телеграм-бот
Bot = telebot.TeleBot(Conf.tg_Token)

# Слой 0
@Bot.message_handler(commands=['start']) # Меню бота
def Start (message : telebot.types.Message):
    if Check_T_ID (message.chat.id):
        if Get_Role_User(message.chat.id) == "Пользователь":
            keyboard = telebot.types.InlineKeyboardMarkup()
            Button_Search = telebot.types.InlineKeyboardButton("Поиск", callback_data='Search_')
            Button_Like = telebot.types.InlineKeyboardButton("Лайки", callback_data='Like_')
            Button_History = telebot.types.InlineKeyboardButton("История", callback_data='History_')
            Button_Settings = telebot.types.InlineKeyboardButton("Настройки", callback_data='Settings_')
            keyboard.add(Button_Search)
            keyboard.add(Button_Like, Button_History)
            keyboard.add(Button_Settings)
            Bot.send_message(message.chat.id,
                            f'Movie Review - сервис для просмотра афиш фильмов. \nБот даст вам весь функцинал сайта прямо в мессенджере. \nПриветствую, {Get_Name_User(message.chat.id)}.',
                            reply_markup=keyboard)
        
        elif Get_Role_User(message.chat.id) in ('Модератор', 'Администратор'):
            keyboard = telebot.types.InlineKeyboardMarkup()
            Button_Search = telebot.types.InlineKeyboardButton("Поиск", callback_data='Search_')
            Button_Like = telebot.types.InlineKeyboardButton("Лайки", callback_data='Like_')
            Button_History = telebot.types.InlineKeyboardButton("История", callback_data='History_')
            Button_Settings = telebot.types.InlineKeyboardButton("Настройки", callback_data='Settings_')
            Button_User = telebot.types.InlineKeyboardButton("Статистика", callback_data='View_User_')
            keyboard.add(Button_Search)
            keyboard.add(Button_Like, Button_History)
            keyboard.add(Button_Settings)
            keyboard.add(Button_User)
            Bot.send_message(message.chat.id,
                            f'Movie Review - сервис для просмотра афиш фильмов. \nБот даст вам весь функцинал сайта прямо в мессенджере. \nПриветствую, {Get_Name_User(message.chat.id)}. Ваша роль: {Get_Role_User(message.chat.id)}.',
                            reply_markup=keyboard)

    else:
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Log = telebot.types.InlineKeyboardButton("Войти", callback_data='Login_')
        Button_Reg = telebot.types.InlineKeyboardButton("Зарегистрироваться", callback_data='Registration_')
        keyboard.add(Button_Log, Button_Reg)
        Bot.send_message(message.chat.id,
                        f'Movie Review - сервис для просмотра афиш фильмов. \nБот даст вам весь функцинал сайта прямо в мессенджере. Авторизуйтесь.',
                        reply_markup=keyboard)

# Слой 1
@Bot.message_handler(commands=['log']) # Авторизация
def Login (message : telebot.types.Message):
    Sent = Bot.send_message(message.chat.id,
                     'Авторизация \nВведите логин:')

    Bot.register_next_step_handler(Sent, Login_Password)

def Login_Password(message : telebot.types.Message):
    User_Save_Auth_Login(message.chat.id, message.text)

    Sent = Bot.send_message(message.chat.id,
                     'Авторизация \nВведите пароль:')

    Bot.register_next_step_handler(Sent, Login_Password_Save)

def Login_Password_Save(message : telebot.types.Message):
    User_Save_Auth_Password(message.chat.id, message.text)
    Data = User_Data[message.chat.id]

    if Check_Login(Data["Auth_Login"]) and Check_Password(Data["Auth_Password"]):
        Update_User(message.chat.id, Data["Auth_Login"])

        Start(message)
    else:
        Bot.send_message(message.chat.id,
                     f'Неправильно введён логин или пароль!')

@Bot.message_handler(commands=['reg']) # Регистрация
def Registration (message : telebot.types.Message):
    keyboard = telebot.types.InlineKeyboardMarkup()
    Button_T_Username = telebot.types.InlineKeyboardButton("Из Telegram", callback_data='T_Username')
    Button_U_Username = telebot.types.InlineKeyboardButton("Свой", callback_data='U_Username')
    keyboard.add(Button_T_Username, Button_U_Username)
    Bot.send_message(message.chat.id,
                     f'Регистрация \nВведите ник', reply_markup=keyboard)

def Registration_FIO (message : telebot.types.Message):
    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nВведите ФИО:')

    Bot.register_next_step_handler(Sent, Registration_Gender)

def Registration_Gender(message : telebot.types.Message):
    User_Save_FIO(message.chat.id, message.text)

    keyboard = telebot.types.InlineKeyboardMarkup()
    Button_M = telebot.types.InlineKeyboardButton("Мужской", callback_data='M_User')
    Button_W = telebot.types.InlineKeyboardButton("Женский", callback_data='W_User')
    keyboard.add(Button_M, Button_W)
    Bot.send_message(message.chat.id,
                     f'Регистрация \nВыберите пол:', reply_markup=keyboard)

def Registration_Age (message : telebot.types.Message):
    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nВведите возраст:')

    Bot.register_next_step_handler(Sent, Registration_Password)

def Registration_Password(message : telebot.types.Message):
    User_Save_Age(message.chat.id, int(message.text))

    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nВведите пароль:')

    Bot.register_next_step_handler(Sent, Registration_Email)

def Registration_Email(message : telebot.types.Message):
    User_Save_Auth_Password(message.chat.id, message.text)

    Sent = Bot.send_message(message.chat.id,
                     f'Регистрация \nВведите почту:')

    Bot.register_next_step_handler(Sent, Registration_End)

def Registration_End(message : telebot.types.Message):
    User_Save_Email(message.chat.id, message.text)
    Data = User_Data[message.chat.id]

    Reg(Data["Username"], Data["FIO"], Data["Gender"], Data["Age"], Data["Password"], message.chat.id, 1, Data["Email"])
    Bot.send_message(message.chat.id,
                     f'Спасибо за регистрацию!')

    Start(message)

# Слой 2 (Пользователь)
@Bot.message_handler(commands=['search']) # Поиск фильмов
def Search_Film (message : telebot.types.Message):
    if Check_T_ID(message.chat.id):
        Bot.send_message(message.chat.id,
                     f'Напишите название фильма:')
        
        Bot.register_next_step_handler(message, Search)
    else:
        Bot.send_message(message.chat.id,
                     f'Вы не зарегистрированы! Для регистрации используйте /reg')

@Bot.message_handler(commands=['like']) # Просморт понравивщихся фильмов
def Like_Film (message : telebot.types.Message):
    if Check_T_ID(message.chat.id):
        Bot.send_message(message.chat.id,
                     f'Понравившиеся фильмы')
        Actives = Get_User_Actives(message.chat.id) # 0 - ID, 1 - Оценка, 2 - Лайк

        Active_list = []
        for i in range(len(Actives)):
            Film_Name = Get_Info_Film(Actives[i][0])
            Film_Name = Film_Name[0]
            Film_Like = Actives[i][2]
            Film_Evaluation = Actives[i][1]

            if Film_Like == 1:
                Active_list.append([Film_Name, Film_Evaluation])

        Num_lock = 40
        Num = 0

        message_text = ''

        for Name, Evaluation in Active_list:
            if len(message_text.splitlines()) >= Num_lock:
                Bot.send_message(message.chat.id,
                                    f'{message_text}')

                message_text = ''

            message_text += f'{Name} Оценка: {Evaluation}\n'
            Num += 1

            if Num == len(Active_list):
                Bot.send_message(message.chat.id,
                                    f'{message_text}')
        
    else:
        Bot.send_message(message.chat.id,
                     f'Вы не зарегистрированы! Для регистрации используйте /reg')

@Bot.message_handler(commands=['history']) # Просморт понравивщихся фильмов
def History (message : telebot.types.Message):
    if Check_T_ID(message.chat.id):
        Bot.send_message(message.chat.id,
                     f'История просмотров')

        Actives = Get_User_Actives(message.chat.id)
        
        Active_list = []
        for i in range(len(Actives)):
            Film_Name = Get_Info_Film(Actives[i][0])
            Film_Name = Film_Name[0]
            Film_Like = Actives[i][2]
            Film_Evaluation = Actives[i][1]

            Active_list.append([Film_Name, Film_Like, Film_Evaluation])
        
        Num_lock = 40
        Num = 0

        message_text = ''

        for Name, Like, Evaluation in Active_list:
            if len(message_text.splitlines()) >= Num_lock:
                print("Тест "+ message_text)
                Bot.send_message(message.chat.id,
                                    f'{message_text}')

                message_text = ''

            if Like == 1:
                message_text += f'{Name} Оценка: {Evaluation} Лайк: Да\n'

            else:
                message_text += f'{Name} Оценка: {Evaluation} Лайк: Нет\n'
            Num += 1

            if Num == len(Active_list):
                Bot.send_message(message.chat.id,
                                    f'{message_text}')

    else:
        Bot.send_message(message.chat.id,
                     f'Вы не зарегистрированы! Для регистрации используйте /reg')

@Bot.message_handler(commands=['feedback']) # Обратная связь
def Feedback (message : telebot.types.Message):
    if Check_T_ID(message.chat.id):
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Send = telebot.types.InlineKeyboardButton("Отправить", callback_data='Send_Feedback_')
        Button_Comment = telebot.types.InlineKeyboardButton("Коментарий", callback_data='Comment_Feedback_')
        Button_Evaluation = telebot.types.InlineKeyboardButton("Оценка", callback_data='Evaluation_Feedback_')
        keyboard.add(Button_Comment, Button_Evaluation)
        keyboard.add(Button_Send)

        Data = User_Data[message.chat.id]
        try:
            if "Evaluation" not in Data:
                User_Save_Evaluation(message.chat.id)
        
        except NameError:
            User_Save_Evaluation(message.chat.id)

        try:
            if "Comment" not in Data:
                User_Save_Comment(message.chat.id)

        except NameError:
            User_Save_Comment(message.chat.id)

        Data = User_Data[message.chat.id]
        Bot.send_message(message.chat.id,
                     f'Обратная связь \nОценка: {Data["Evaluation"]}/10 \nКоментарий: \n{Data["Comment"]}', reply_markup=keyboard)
    else:
        Bot.send_message(message.chat.id,
                     f'Вы не зарегистрированы! Для регистрации используйте /reg')

# Слой 2 (Администратор)
@Bot.message_handler(commands=['view_user']) # Просмотр статистики пользователей
def User_Info (message : telebot.types.Message):
    if Check_T_ID(message.chat.id):
        if Get_Role_User(message.chat.id) in ('Модератор', 'Администратор'):
            User_Data = Get_Info_Users()

            User_Gender = [elem[0] for elem in User_Data]
            User_Age = [elem[1] for elem in User_Data]


            # Обработка пола
            All_Gender = len(User_Gender)
            Gender_M = 0
            Gender_W = 0
            
            for i in range(All_Gender):
                if User_Gender[i] == 1:
                    Gender_M += 1
                elif User_Gender[i] == 2:
                    Gender_W += 1

            Gender_M_P = round((Gender_M * 100) / All_Gender, 2)
            Gender_W_P = round((Gender_W * 100) / All_Gender, 2)

            # Обработка возроста
            All_Age = len(User_Age)
            Age1 = 0 # -17
            Age2 = 0 # 18-24
            Age3 = 0 # 25–34
            Age4 = 0 # 35–44
            Age5 = 0 # 45–54
            Age6 = 0 # 55–64
            Age7 = 0 # 65+

            for i in range(All_Age):
                if 0 <= User_Age[i] <= 17:
                    Age1 += 1
                elif 18 <= User_Age[i] <= 24:
                    Age2 += 1
                elif 25 <= User_Age[i] <= 34:
                    Age3 += 1
                elif 35 <= User_Age[i] <= 44:
                    Age4 += 1
                elif 45 <= User_Age[i] <= 54:
                    Age5 += 1
                elif 55 <= User_Age[i] <= 64:
                    Age6 += 1
                elif User_Age[i] >= 65:
                    Age7 += 1

            Age1_P = round((Age1 * 100) / All_Age, 2)
            Age2_P = round((Age2 * 100) / All_Age, 2)
            Age3_P = round((Age3 * 100) / All_Age, 2)
            Age4_P = round((Age4 * 100) / All_Age, 2)
            Age5_P = round((Age5 * 100) / All_Age, 2)
            Age6_P = round((Age6 * 100) / All_Age, 2)
            Age7_P = round((Age7 * 100) / All_Age, 2)
            
            Bot.send_message(message.chat.id,
                     f'Статистика пользователей: \nВсего пользователей: {All_Gender} \n\n% полов: \nМужчин - {Gender_M_P}% \nЖенщин - {Gender_W_P}% \n\n% возрастов: \nМеньше 18 - {Age1_P}% \n18-24 - {Age2_P}% \n25-34 - {Age3_P}% \n35-44 - {Age4_P}% \n45-54 - {Age5_P}% \n55-64 - {Age6_P}% \nБолее 65 - {Age7_P}%')
        else:
            Bot.send_message(message.chat.id,
                     f'У вас недостаточно прав для доступа к этой функции!')
    else:
        Bot.send_message(message.chat.id,
                     f'Вы не зарегистрированы! Для регистрации используйте /reg')

@Bot.message_handler(commands=['settings']) # Настройки
def Settings (message : telebot.types.Message):
    if Check_T_ID(message.chat.id):
        Data = Get_Info_User(message.chat.id)
        if Data[2] == 1:
            Gender = "М"
        elif Data[2] == 2:
            Gender = "Ж"

        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Name = telebot.types.InlineKeyboardButton("Изменить ник", callback_data='Сhange_Name') 
        Button_FIO = telebot.types.InlineKeyboardButton("Изменить ФИО", callback_data='Сhange_FIO') 
        Button_Gender = telebot.types.InlineKeyboardButton("Изменить пол", callback_data='Сhange_Gender') 
        Button_Age = telebot.types.InlineKeyboardButton("Изменить возраст", callback_data='Сhange_Age') 
        Button_Email = telebot.types.InlineKeyboardButton("Изменить почту", callback_data='Сhange_Email')
        keyboard.add(Button_Name, Button_FIO, Button_Gender, Button_Age, Button_Email, row_width=1)
        Bot.send_message(message.chat.id,
                     f'Информация о пользователе: \nНик: {Data[0]} \nФИО: {Data[1]} \nПол: {Gender} \nВозраст: {Data[3]} \nПочта: {Data[4]}', 
                     reply_markup=keyboard)
    else:
        Bot.send_message(message.chat.id,
                     f'Вы не зарегистрированы! Для регистрации используйте /reg')

@Bot.message_handler(commands=['creators']) # Создатели
def Creators (message : telebot.types.Message):
    keyboard = telebot.types.InlineKeyboardMarkup()
    Button_Kon = telebot.types.InlineKeyboardButton("Поддержать Konaca", url='https://www.donationalerts.com/r/konaca_')
    Button_Rin = telebot.types.InlineKeyboardButton("Поддержать Rin", url='https://www.donationalerts.com/r/rin128')
    Button_Ari = telebot.types.InlineKeyboardButton("Поддержать Ari", url='')
    keyboard.add(Button_Kon, Button_Rin)
    keyboard.add(Button_Ari)

    Bot.send_message(message.chat.id,
                     f'Команда сервиса Movie Review: \nKonaca (Влад) - Создатель и программист Telegram-бота \nRin (Марина) - программист сайта \nAri - программист тех. поддержки',
                     reply_markup=keyboard)

@Bot.callback_query_handler(func=lambda call: True) # Обработка callback
def Handle_Query(call : telebot.types.CallbackQuery):
    def Handle_Login_ (call : telebot.types.CallbackQuery):
        Login(call.message)
    
    def Handle_Registration_ (call : telebot.types.CallbackQuery):
        Registration(call.message)
        
    def Handle_Evaluation_Feedback_ (call : telebot.types.CallbackQuery):
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Evaluation_1 = telebot.types.InlineKeyboardButton("1", callback_data='1_')
        Button_Evaluation_2 = telebot.types.InlineKeyboardButton("2", callback_data='2_')
        Button_Evaluation_3 = telebot.types.InlineKeyboardButton("3", callback_data='3_')
        Button_Evaluation_4 = telebot.types.InlineKeyboardButton("4", callback_data='4_')
        Button_Evaluation_5 = telebot.types.InlineKeyboardButton("5", callback_data='5_')
        Button_Evaluation_6 = telebot.types.InlineKeyboardButton("6", callback_data='6_')
        Button_Evaluation_7 = telebot.types.InlineKeyboardButton("7", callback_data='7_')
        Button_Evaluation_8 = telebot.types.InlineKeyboardButton("8", callback_data='8_')
        Button_Evaluation_9 = telebot.types.InlineKeyboardButton("9", callback_data='9_')
        Button_Evaluation_10 = telebot.types.InlineKeyboardButton("10", callback_data='10_')
        keyboard.add(Button_Evaluation_1, Button_Evaluation_2, Button_Evaluation_3, Button_Evaluation_4, Button_Evaluation_5, Button_Evaluation_6, Button_Evaluation_7, Button_Evaluation_8, Button_Evaluation_9, Button_Evaluation_10, row_width=5)

        Bot.send_message(call.message.chat.id,
                            f'Выберите оценку:', reply_markup=keyboard)
        
    def Handle_1_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 1)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_2_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 2)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_3_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 3)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_4_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 4)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_5_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 5)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_6_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 6)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_7_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 7)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_8_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 8)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_9_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 9)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_10_(call : telebot.types.CallbackQuery):
        User_Save_Evaluation(call.message.chat.id, 10)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_Comment_Feedback_(call : telebot.types.CallbackQuery):
        Sent = Bot.send_message(call.message.chat.id,
                        f'Напишите коментарий:')

        Bot.register_next_step_handler(Sent, Update_G_Comment_T)

    def Handle_Send_Feedback_(call : telebot.types.CallbackQuery):
        Data = User_Data[call.message.chat.id]
        Insert_FeedBack(call.message.chat.id, Data["Evaluation"], Data["Comment"])
        Bot.send_message(call.message.chat.id,
                            f'Спасибо за ваш отзыв!')

    def Handle_Search_(call : telebot.types.CallbackQuery):
        Search_Film(call.message)

    def Handle_Like_(call : telebot.types.CallbackQuery):
        Like_Film(call.message)

    def Handle_History_(call : telebot.types.CallbackQuery):
        History(call.message)

    def Handle_Settings_(call : telebot.types.CallbackQuery):
        Settings(call.message)

    def Handle_View_User_(call : telebot.types.CallbackQuery):
        User_Info(call.message)

    def Handle_Start_(call : telebot.types.CallbackQuery):
        Start(call.message)

    def Handle_Сhange_Name(call : telebot.types.CallbackQuery):
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Name_Telegram = telebot.types.InlineKeyboardButton("Из Telegram", callback_data='Name_Telegram')
        Button_Name_User = telebot.types.InlineKeyboardButton("Ввести своё", callback_data='Name_User')
        keyboard.add(Button_Name_Telegram, Button_Name_User, row_width=1)
        Bot.send_message(call.message.chat.id,
                            f'Выберите:', reply_markup=keyboard)

    def Handle_Name_Telegram(call : telebot.types.CallbackQuery):
        Update_User_Name(call.message.chat.id, call.message.from_user.username)
        Bot.send_message(call.message.chat.id,
                            f'Имя изменено!')

    def Handle_Name_User(call : telebot.types.CallbackQuery):
        Sent = Bot.send_message(call.message.chat.id,
                            f'Введите имя:')
            
        Bot.register_next_step_handler(Sent, Update_User_Name_T)

    def Handle_Сhange_FIO(call : telebot.types.CallbackQuery):
        Sent = Bot.send_message(call.message.chat.id,
                            f'Введите ФИО:')
            
        Bot.register_next_step_handler(Sent, Update_User_FIO_T)

    def Handle_Сhange_Gender(call : telebot.types.CallbackQuery):
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Gender_M = telebot.types.InlineKeyboardButton("М", callback_data='Gender_M')
        Button_Gender_W = telebot.types.InlineKeyboardButton("Ж", callback_data='Gender_W')
        keyboard.add(Button_Gender_M, Button_Gender_W, row_width=2)
        Bot.send_message(call.message.chat.id,
                            f'Ваш пол:', reply_markup=keyboard)

    def Handle_Gender_M(call : telebot.types.CallbackQuery):
        Update_User_Gender(call.message.chat.id, 1)
        Bot.send_message(call.message.chat.id,
                            f'Пол изменен!')

    def Handle_Gender_W(call : telebot.types.CallbackQuery):
        Update_User_Gender(call.message.chat.id, 2)
        Bot.send_message(call.message.chat.id,
                            f'Пол изменен!')

    def Handle_Сhange_Age(call : telebot.types.CallbackQuery):
        Sent = Bot.send_message(call.message.chat.id,
                            f'Введите возраст:')
            
        Bot.register_next_step_handler(Sent, Update_User_Age_T)

    def Handle_Сhange_Email(call : telebot.types.CallbackQuery):
        Sent = Bot.send_message(call.message.chat.id,
                            f'Введите почту:')
            
        Bot.register_next_step_handler(Sent, Update_User_Email_T)

    def Handle_T_Username(call : telebot.types.CallbackQuery):
        if call.message.from_user.is_bot:
            Handle_U_Username(call)
        else:
            User_Save_Username(call.message.chat.id, call.message.from_user.username)
        
            Registration_FIO(call.message)

    def Handle_U_Username(call : telebot.types.CallbackQuery):
        Sent = Bot.send_message(call.message.chat.id,
                            f'Введите ник:')

        Bot.register_next_step_handler(Sent, Update_G_Username_T)

    def Handle_M_User(call : telebot.types.CallbackQuery):
        User_Save_Gender(call.message.chat.id, 1)
        Registration_Age(call.message)

    def Handle_W_User(call : telebot.types.CallbackQuery):
        User_Save_Gender(call.message.chat.id, 2)
        Registration_Age(call.message)

    def Handle_Like__(call : telebot.types.CallbackQuery):
        User_Save_Like_Film(call.message.chat.id, 1)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')
    
    def Handle_Evaluation__(call : telebot.types.CallbackQuery):
        keyboard = telebot.types.InlineKeyboardMarkup()
        Button_Evaluation_1 = telebot.types.InlineKeyboardButton("1", callback_data='1__')
        Button_Evaluation_2 = telebot.types.InlineKeyboardButton("2", callback_data='2__')
        Button_Evaluation_3 = telebot.types.InlineKeyboardButton("3", callback_data='3__')
        Button_Evaluation_4 = telebot.types.InlineKeyboardButton("4", callback_data='4__')
        Button_Evaluation_5 = telebot.types.InlineKeyboardButton("5", callback_data='5__')
        Button_Evaluation_6 = telebot.types.InlineKeyboardButton("6", callback_data='6__')
        Button_Evaluation_7 = telebot.types.InlineKeyboardButton("7", callback_data='7__')
        Button_Evaluation_8 = telebot.types.InlineKeyboardButton("8", callback_data='8__')
        Button_Evaluation_9 = telebot.types.InlineKeyboardButton("9", callback_data='9__')
        Button_Evaluation_10 = telebot.types.InlineKeyboardButton("10", callback_data='10__')
        keyboard.add(Button_Evaluation_1, Button_Evaluation_2, Button_Evaluation_3, Button_Evaluation_4, Button_Evaluation_5, Button_Evaluation_6, Button_Evaluation_7, Button_Evaluation_8, Button_Evaluation_9, Button_Evaluation_10, row_width=5)

        Bot.send_message(call.message.chat.id,
                                f'Выберите оценку:', reply_markup=keyboard)

    def Handle_1__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 1)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_2__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 2)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_3__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 3)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_4__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 4)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_5__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 5)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_6__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 6)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_7__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 7)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_8__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 8)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_9__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 9)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_10__(call : telebot.types.CallbackQuery):
        User_Save_Evaluation_Film(call.message.chat.id, 10)
        Bot.send_message(call.message.chat.id,
                            f'Данные сохранены!')

    def Handle_Check_Another(call : telebot.types.CallbackQuery):
        if 'Send__' in call.data:
            try:
                Data = User_Data[call.message.chat.id]
                Film_ID = call.data[6:]
                Insert_Active(call.message.chat.id, int(Film_ID), Data["Evaluation_Film"], Data["Like_Film"])
                Bot.send_message(call.message.chat.id,
                                f'Благодарим за оценку!')
            except NameError:
                User_Save_Evaluation_Film(call.message.chat.id, -1)
                User_Save_Like_Film(call.message.chat.id, 0)


    Actions = {
        'Login_': lambda Param: Handle_Login_(Param),

        'Registration_': lambda Param: Handle_Registration_(Param),

        'Evaluation_Feedback_': lambda Param: Handle_Evaluation_Feedback_(Param),
        '1_': lambda Param: Handle_1_(Param),
        '2_': lambda Param: Handle_2_(Param),
        '3_': lambda Param: Handle_3_(Param),
        '4_': lambda Param: Handle_4_(Param),
        '5_': lambda Param: Handle_5_(Param),
        '6_': lambda Param: Handle_6_(Param),
        '7_': lambda Param: Handle_7_(Param),
        '8_': lambda Param: Handle_8_(Param),
        '9_': lambda Param: Handle_9_(Param),
        '10_': lambda Param: Handle_10_(Param),

        'Comment_Feedback_': lambda Param: Handle_Comment_Feedback_(Param),

        'Send_Feedback_': lambda Param: Handle_Send_Feedback_(Param),

        'Search_': lambda Param: Handle_Search_(Param),
        'Like_': lambda Param: Handle_Like_(Param),
        'History_': lambda Param: Handle_History_(Param),
        'Settings_': lambda Param: Handle_Settings_(Param),
        'View_User_': lambda Param: Handle_View_User_(Param),
        'Start_': lambda Param: Handle_Start_(Param),

        'Сhange_Name': lambda Param: Handle_Сhange_Name(Param),
        'Name_Telegram': lambda Param: Handle_Name_Telegram(Param),
        'Name_User': lambda Param: Handle_Name_User(Param),

        'Сhange_FIO': lambda Param: Handle_Сhange_FIO(Param),

        'Сhange_Gender': lambda Param: Handle_Сhange_Gender(Param),
        'Gender_M': lambda Param: Handle_Gender_M(Param),
        'Gender_W': lambda Param: Handle_Gender_W(Param),

        'Сhange_Age': lambda Param: Handle_Сhange_Age(Param),

        'Сhange_Email': lambda Param: Handle_Сhange_Email(Param),

        'T_Username': lambda Param: Handle_T_Username(Param),
        'U_Username': lambda Param: Handle_U_Username(Param),

        'M_User': lambda Param: Handle_M_User(Param),
        'W_User': lambda Param: Handle_W_User(Param),

        'Like__': lambda Param: Handle_Like__(Param),

        'Evaluation__': lambda Param: Handle_Evaluation__(Param),
        '1__': lambda Param: Handle_1__(Param),
        '2__': lambda Param: Handle_2__(Param),
        '3__': lambda Param: Handle_3__(Param),
        '4__': lambda Param: Handle_4__(Param),
        '5__': lambda Param: Handle_5__(Param),
        '6__': lambda Param: Handle_6__(Param),
        '7__': lambda Param: Handle_7__(Param),
        '8__': lambda Param: Handle_8__(Param),
        '9__': lambda Param: Handle_9__(Param),
        '10__': lambda Param: Handle_10__(Param),
    }
    Actions.get(call.data, lambda Param: Handle_Check_Another(Param))(call)

Bot.infinity_polling()
while 1 > 0:
    time.sleep(300)
    Update_Evaluation(datetime.datetime.now())


